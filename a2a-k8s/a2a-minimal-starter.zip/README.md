
# A2A Minimal Starter (Kubernetes)

Ultra-simple baseline for an A2A-style multi-agent system on Kubernetes.
- 3 agents (coordinator, echo, math) expose a JSON-RPC `/a2a` endpoint.
- Each agent serves an **Agent Card** at `/.well-known/agent.json` with a single `message/send` capability.
- A barebones web app forwards user `/task` to the coordinator’s `/a2a`.

## Run locally

```bash
# In separate shells:
uvicorn worker-echo.app:app --port 8001 --reload
uvicorn worker-math.app:app --port 8002 --reload
uvicorn coordinator.app:app --port 8000 --reload
uvicorn webapp.app:app --port 8080 --reload
```

Test:
```bash
curl -s localhost:8001/.well-known/agent.json | jq .
curl -s localhost:8002/.well-known/agent.json | jq .

curl -s -X POST localhost:8000/a2a -H 'content-type: application/json' -d '{
  "jsonrpc":"2.0",
  "method":"message/send",
  "id":"1",
  "params":{"message":{"parts":[{"text":"add 2 3"}],"role":"user"}}
}' | jq .

curl -s -X POST localhost:8080/task -H 'content-type: application/json' -d '{"text":"add 2 3"}' | jq .
```

## Build images (example)

```bash
docker build -t ghcr.io/example/worker-echo:latest ./worker-echo
docker build -t ghcr.io/example/worker-math:latest ./worker-math
docker build -t ghcr.io/example/coordinator:latest ./coordinator
docker build -t ghcr.io/example/webapp:latest ./webapp
```

## Deploy to Kubernetes

Replace image names in `k8s/*.yaml` or set your own registry, then:

```bash
kubectl apply -f k8s/00-namespace.yaml
kubectl apply -f k8s/10-worker-echo.yaml
kubectl apply -f k8s/11-worker-math.yaml
kubectl apply -f k8s/20-coordinator.yaml
kubectl apply -f k8s/30-webapp.yaml
# Optional ingress (requires an ingress controller)
kubectl apply -f k8s/40-ingress.yaml
```

## Notes
- Endpoint names follow common practice: `message/send` for a minimal **A2A**-style JSON-RPC method.
- Agent Cards are intentionally minimal and unauthenticated for clarity.
- For production: add auth (OAuth/JWT), mTLS in-mesh, readiness probes, and run Inspector/TCK.
