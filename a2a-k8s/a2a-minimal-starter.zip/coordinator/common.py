
# Minimal JSON-RPC helpers (no external lib required)
from typing import Any, Optional
from pydantic import BaseModel
from fastapi import HTTPException

class JSONRPCRequest(BaseModel):
    jsonrpc: str
    method: str
    params: Optional[dict] = None
    id: Optional[Any] = None

def make_result(result: Any, id: Any = None):
    return {"jsonrpc": "2.0", "result": result, "id": id}

def make_error(code: int, message: str, id: Any = None):
    return {"jsonrpc": "2.0", "error": {"code": code, "message": message}, "id": id}

def validate_request(req: JSONRPCRequest):
    if req.jsonrpc != "2.0":
        raise HTTPException(status_code=400, detail="jsonrpc must be '2.0'")
    if not req.method:
        raise HTTPException(status_code=400, detail="method is required")
