
from fastapi import FastAPI
import os, httpx

app = FastAPI(title="Coordinator Agent")
from common import JSONRPCRequest, make_result, make_error, validate_request

ECHO_URL = os.environ.get("ECHO_URL", "http://worker-echo:8001/a2a")
MATH_URL = os.environ.get("MATH_URL", "http://worker-math:8002/a2a")
SERVICE_BASE_URL = os.environ.get("SERVICE_BASE_URL", "http://localhost:8000")

@app.get("/.well-known/agent.json")
def agent_card():
    return {
        "id": "coordinator-agent",
        "name": "Coordinator Agent",
        "description": "Sequentially calls Echo and Math agents via A2A and combines results.",
        "protocolVersion": "0.3.0",
        "endpoints": {"jsonrpc": {"url": f"{SERVICE_BASE_URL}/a2a", "transport": "http"}},
        "authentication": {"type": "none"},
        "capabilities": {"message": ["send"]}
    }

async def call_a2a(url: str, text: str):
    payload = {
        "jsonrpc": "2.0",
        "method": "message/send",
        "id": "1",
        "params": {"message": {"parts": [{"text": text}], "role": "user"}}
    }
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(url, json=payload)
        r.raise_for_status()
        data = r.json()
        parts = (data.get("result") or {}).get("parts", [])
        if parts and "text" in parts[0]:
            return parts[0]["text"]
        return str(data)

@app.post("/a2a")
async def a2a_endpoint(req: JSONRPCRequest):
    validate_request(req)
    if req.method in ["message/send", "message.send"]:
        text = ""
        try:
            parts = (req.params or {}).get("message", {}).get("parts", [])
            if parts and "text" in parts[0]:
                text = parts[0]["text"]
        except Exception:
            pass
        echo = await call_a2a(ECHO_URL, text)
        math = await call_a2a(MATH_URL, text)
        combined = f"[echo] {echo} | [math] {math}"
        return make_result({"parts": [{"text": combined}], "role": "agent"}, req.id)
    return make_error(-32601, f"Method not found: {req.method}", req.id)
